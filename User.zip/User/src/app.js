const express = require('express');
const app = express();
require('./db/conn');
const path = require('path');
const port = process.env.PORT || 3000;
const hbs = require('hbs');
const User = require('./models/register');
const async = require('hbs/lib/async');
//const static_path = path.join(__dirname,'../public');
//console.log(path.join((__dirname,'../public')));
const template_path = path.join(__dirname,'../templates/views')
const partials_path = path.join(__dirname,"../templates/partials");
app.use(express.json());
app.use(express.urlencoded({extended:false}));
//app.use(express.static(static_path));
app.set('view engine','hbs');
app.set('views',template_path);
hbs.registerPartials(partials_path);

app.get('/',(req,res)=>{
    //res.send('Dark Side');
    res.render('index')
});

app.get('/register',(req,res)=>{
    //res.send('Dark Side');
    res.render('register')
});

app.post('/register',async(req,res)=>{
    try{

        const userRegister =  new User({
            username : req.body.username,
            email : req.body.email,
            password : req.body.password
        });

       const register = await userRegister.save();
      

        console.log(req.body.username);
        console.log(req.body);
        res.send(req.body);

    }catch(err){
        res.status(400).send(err);
    }
})

app.listen(port,()=>{
    console.log(`Server Is Running At Port Number ${port}`);
})